﻿using Gatam.Domain;

namespace Gatam.WebAppBegeleider.Extensions.RequestObjects
{
    public class UpdateQuestionPriorityRequestObject
    {
        public QuestionPriority QuestionPriority { get; set; }
    }
}
