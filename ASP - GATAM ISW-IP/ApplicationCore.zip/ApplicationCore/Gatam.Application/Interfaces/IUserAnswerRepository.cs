﻿using Gatam.Domain;

namespace Gatam.Application.Interfaces;

    public interface IUserAnswerRepository : IGenericRepository<UserAnswer>
    {
    }   

